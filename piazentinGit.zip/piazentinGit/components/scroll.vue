<template>
    <div id="progressbar">
      <div id="progressbar-container">
        <div id="bullet"></div>
        <span id="liner"></span>
      </div>
      <span id="progressbar-text">SCROLL</span>
    </div>
</template>

<script>
    export default {
        name: 'scroll'
    }
</script>