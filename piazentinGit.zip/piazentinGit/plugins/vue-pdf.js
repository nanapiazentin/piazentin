import Vue from 'vue'
import pdf from "vue-pdf";

Vue.component('pdf', pdf)