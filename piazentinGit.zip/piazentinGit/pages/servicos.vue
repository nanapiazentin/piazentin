<template>
  <div>
    <section data-scroll-section class="container section-bottom" id="container">
        <div class="row loco-section" id="row" data-scroll data-scroll-class="loco-show">
            <div class="col-12-sm col-2-md col-start-1-sm col-start-2-md fixed-nav">
                <div class="item-top" data-scroll data-scroll-sticky data-scroll-target="#row">
                    <ul id="fixnav">
                        <li>
                            <a id="fixnav-propriedade-intelectual" href="#propriedade-intelectual" data-scroll-to>Propriedade Intelectual</a>
                        </li>
                        <li>
                            <a id="fixnav-direito-autoral" href="#direito-autoral" data-scroll-to>Direito Autoral</a>
                        </li>
                        <li>
                            <a id="fixnav-marcas" href="#marcas" data-scroll-to>Marcas</a>
                        </li>
                        <li>
                            <a id="fixnav-patentes" href="#patentes" data-scroll-to>Patentes</a>
                        </li>
                        <li>
                            <a id="fixnav-desenhos-industriais" href="#desenhos-industriais" data-scroll-to>Desenhos Industriais</a>
                        </li>
                        <li>
                            <a id="fixnav-direito-do-entretenimento" href="#direito-do-entretenimento" data-scroll-to>Direito do Entretenimento</a>
                        </li>
                        <li>
                            <a id="fixnav-direito-empresarial" href="#direito-empresarial" data-scroll-to>Direito Empresarial</a>
                        </li>
                        <li>
                            <a id="fixnav-direito-digital" href="#direito-digital" data-scroll-to>Direito Digital</a>
                        </li>
                        <li>
                            <a id="fixnav-direito-publico" href="#direito-publico" data-scroll-to>Direito Público</a>
                        </li>
                        <li>
                            <a id="fixnav-resolucao-de-conflitos" href="#resolucao-de-conflitos" data-scroll-to>Resolução de conflitos </a>
                        </li>
                        <li>
                            <a id="fixnav-contratos" href="#contratos" data-scroll-to>Contratos</a>
                        </li>
                        <li>
                            <a id="fixnav-licencas" href="#licencas" data-scroll-to>Licenças</a>
                        </li>
                        <li>
                            <a id="fixnav-projetos-culturais" href="#projetos-culturais" data-scroll-to>Projetos Culturais</a>
                        </li>
                        <li>
                            <a id="fixnav-cultura-livre" href="#cultura-livre" data-scroll-to>Cultura Livre</a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="col-10-sm col-7-md col-start-2-sm col-start-5-md">
                <div id="propriedade-intelectual" data-scroll data-scroll-class="loco-show" data-scroll-call="propriedade-intelectual" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Propriedade <br>Intelectual</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Propriedade intelectual refere-se a criações do espírito que são protegidas 
                                pela lei. Propriedade Intelectual, ou “PI”, é uma propriedade que você pode 
                                possuir, ceder ou licenciar. Os direitos de propriedade intelectual incluem 
                                direitos autorais, propriedade industrial com marcas, patentes, desenhos 
                                industriais e segredos comerciais e ainda a proteção Sui Generis. 
                                Cada um desses tipos de propriedade é separado e distinto. 
                                Todos esses tipos podem ser importantes para o seu negócio.
                                <br><br>
                                A Propriedade Intelectual sustenta tudo o que fazemos. Somos especialistas 
                                e aconselhamos em todas as áreas de Propriedade Intelectual. Nosso trabalho 
                                é proteger os direitos de propriedade intelectual de nossos clientes, 
                                caso assim o queiram, ou ajuda-los a alavancar esses direitos para o maior 
                                benefício possível valendo-se de licenças livres. Nossas especialidades em 
                                Propriedade Intelectual incluem desde o registro de direitos autorais na 
                                Biblioteca Nacional e registro de propriedade industrial no INPI a franquias 
                                e transferência de tecnologia.
</p>
                        </div>
                    </div>
                </div>

                <div id="direito-autoral" data-scroll data-scroll-class="loco-show" data-scroll-call="direito-autoral" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Direito <br>Autoral</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Existe um direito autoral em todo trabalho criativo, seja uma música ou um poema ou um
                            desenho ou um vídeo. Os direitos autorais também protegem documentos e materiais
                            comerciais. O proprietário de um direito autoral tem o direito exclusivo de reproduzir,
                            distribuir, exibir, executar, vender e licenciar o trabalho com direitos autorais. Dentre os
                            <br>
                            trabalhos realizados na seara dos Direitos Autorais: Licenciamento, atribuição, violação,
                            direitos morais e direitos conexos dos artistas, direitos dos herdeiros, negociação com titulares
                            para uso em obras criativas culturais, comerciais ou publicitários.</p>
                        </div>
                    </div>
                </div>

                <div id="marcas" data-scroll data-scroll-class="loco-show" data-scroll-call="marcas" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Marcas</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Você dedicou tempo, esforço e dinheiro para criar sua marca. Com a nossa
                            abrangente pesquisa de autorização, garantimos que você terá o direito de usar o nome e o
                            logotipo. É aqui que começamos o processo de defender sua marca: Pesquisa abrangente de
                            banco de dados INPI e registros estaduais, carta de avaliação com os resultados da pesquisa, o
                            nível de risco e as chances de sucesso da marca registrada.</p>
                        </div>
                    </div>
                </div>

                <div id="patentes" data-scroll data-scroll-class="loco-show" data-scroll-call="patentes" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Patentes</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>São muitas as vantagens advindas com a obtenção de uma patente, especialmente sobre o
                            ponto de vista empresarial, agregando valor na atração de novos clientes e investidores, pois
                            estes se sentem mais seguros para investirem em um novo produto. Os serviços no campo das
                            patentes, incluem depósito de pedidos e acompanhamento de todos os serviços
                            administrativos relacionados aos casos em andamento, pesquisas de possibilidade de
                            comercialização de determinados produtos no Brasil (FTO), pesquisas de anterioridade e
                            apresentação de subsídios técnicos para evitar a concessão de patentes de terceiros.</p>
                        </div>
                    </div>
                </div>

                <div id="desenhos-industriais" data-scroll data-scroll-class="loco-show" data-scroll-call="desenhos-industriais" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Desenhos Industriais</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Desenho Industrial é o design do seu produto! Um design inovador é um importante elemento
                            de atração de clientes, pois ao reunir características visuais inovadoras e originais, seu produto
                            passará a ocupar um lugar especial na memória dos consumidores e ganhará valor comercial.
                            Pode ser registrado todo e qualquer produto com aparência nova e original, ou seja, quando
                            resulte em uma configuração visual distintiva em relação a outros objetos (ou padrões)
                            conhecidos. De joias à automóveis o registro de desenho industrial alcança uma grande gama
                            de produtos como móveis, estampas, óculos, embalagens, peças de decoração, e vários
                            outros. Atuamos em todas as etapas da proteção do design, prestando o apoio necessário
                            desde a concepção do produto, até a oposição dos direitos decorrentes do registro.</p>
                        </div>
                    </div>
                </div>

                <div id="direito-do-entretenimento" data-scroll data-scroll-class="loco-show" data-scroll-call="direito-do-entretenimento" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Direito do<br>Entretenimento</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>O Direito do Entretenimento engloba uma variedade de especialidades em vários setores
                            culturais e criativos diferentes. Significa fornecer serviços jurídicos para pessoas e empresas
                            criativas. Pessoas criativas, ou “criativos”, incluem o que tradicionalmente chamamos de
                            “artistas”: autores, músicos, fotógrafos, pintores, escultores, designers gráficos, designers de
                            moda, atores, escritores, cineastas, cinegrafistas, roteiristas, dançarinos, compositores. Um
                            criativo é também qualquer pessoa que considera seu trabalho uma forma de arte. Isso inclui
                            inventores, chefs, cervejeiros artesanais, restauradores, gerentes, agentes, diretores,
                            produtores, arquitetos, editores, professores e empresários de todos os tipos.
                            <br>
                            Nossos clientes comerciais são empresas criativas: produtoras, agências de publicidade,
                            organizações sem fins lucrativos, instituições, empresas de eventos, promoções e festivais,
                            estúdios, distribuidoras, editoras, empresas de design, empresas de desenvolvimento e a lista
                            continua.</p>
                        </div>
                    </div>
                </div>

                <div id="direito-empresarial" data-scroll data-scroll-class="loco-show" data-scroll-call="direito-empresarial" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Direito <br>Empresarial</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Fornecemos consultoria comercial para todos os nossos clientes, em áreas como: Conselho de
                            início de negócios; Criação de uma empresa, formalizando o acordo entre as partes fundadoras
                            (por exemplo, um acordo de parceria ou acordo de acionistas), Contratação com clientes;
                            Termos e condutas de negócios; Contratos de serviços e acordos.
                            <br>
                            Aconselhamos em questões de direito societário, acordos de investimento, emissões de ações,
                            aquisições, vendas de ações, fusões, joint ventures e contratos de serviços de diretores.</p>
                        </div>
                    </div>
                </div>

                <div id="direito-publico" data-scroll data-scroll-class="loco-show" data-scroll-call="direito-publico" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Direito <br>Público</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Estamos preparados para auxiliar nossos clientes em suas diversas relações com o Poder
                            Público, no campo do Direito Administrativo, temos expertise em diversas frentes, como
                            Licitações e Contratações Públicas, Editais, Ações de Improbidade Administrativa, Dano e
                            Ressarcimento aos Cofres Públicos, Processos com o Ministério Público, Controladoria Geral de
                            entes da Federação.</p>
                        </div>
                    </div>
                </div>

                <div id="resolucao-de-conflitos" data-scroll data-scroll-class="loco-show" data-scroll-call="resolucao-de-conflitos" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Resolução de<br>Conflitos</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Conselho inicial: Podemos fornecer conselhos iniciais sobre possíveis reivindicações que
                            possam gerar danos a terceiros. <br>
                            Notificação Extrajudicial: São cartas antes da ação, que podem funcionar como solução a um
                            conflito sem a necessidade de intervenção judicial. Podem ser usadas em relação a quebra de
                            contrato, violação de direitos autorais e diversas outras situações. <br>
                            Reclamações contra você: Somos adeptos em neutralizar alegações e estabelecer contra-
                            notificações para impedir possíveis demandas judiciais. <br>
                            Acordos: Uma vez resolvidos, elaboramos acordos concisos e muito bem definidos em
                            condições confidenciais.</p>
                        </div>
                    </div>
                </div>

                <div id="contratos" data-scroll data-scroll-class="loco-show" data-scroll-call="contratos" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Contratos</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Contratos definem relações comerciais e são uma parte crucial de qualquer negócio bem-
                            sucedido. Nós preparamos contratos personalizados que atendem às necessidades de nossos
                            clientes e protegem seus negócios. Você tem contratos com seus clientes? Com seus
                            contratados e fornecedores independentes? Com seus prestadores de serviços? Tudo isso é
                            importante! Vamos elaborar, revisar, revisar mais uma vez e finalizar os contratos para termos
                            a certeza de termos a melhor redação possível. <br> <br>
                            Os contratos são cruciais para todos os negócios, grandes ou pequenos, novos ou antigos.
                            Todo relacionamento comercial deve ser comemorado em um contrato comercial e, a
                            qualquer momento, qualquer coisa de valor que esteja mudando de mãos deve ser registrada.
                            Os contratos são importantes aliados na estruturação de qualquer negócio.</p>
                        </div>
                    </div>
                </div>

                <div id="licencas" data-scroll data-scroll-class="loco-show" data-scroll-call="licencas" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Licenças</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Uma licença concede direitos de uma parte para outra. Especificamente, a propriedade
                            intelectual é frequentemente licenciada para diversas finalidades. O licenciamento é uma
                            prática importante para muitas empresas e pode ser uma valiosa fonte de receita. As licenças
                            devem ser preparadas adequadamente e o licenciamento deve ser feito corretamente!
                            <br><br>
                            Aconselhamos nossos clientes sobre a estratégia e a forma de conduta de licenciamento.
                            Preparamos licenças claras, concisas e completas que explicam todos os termos importantes e
                            não deixam nada ao acaso.
                            <br><br>
                            Orientamos também sobre os usos de licenças livres e como sua utilização pode ser benéfica
                            para propagação de seu trabalho.</p>
                        </div>
                    </div>
                </div>

                <div id="projetos-culturais" data-scroll data-scroll-class="loco-show" data-scroll-call="projetos-culturais" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Projetos <br>Culturais</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Leis de Incentivo à Cultura: Consultoria sobre os incentivos fiscais aplicáveis a área; Adequação
                            dos projetos às exigências de cada uma das leis; Prestação de contas: Orientação durante a
                            fase de prestação de contas.</p>
                        </div>
                    </div>
                </div>

                <div id="cultura-livre" data-scroll data-scroll-class="loco-show" data-scroll-call="cultura-livre" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Cultura<br>Livre</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>A maioria dos autores, qualquer que seja o seu campo de atuação, tem um genuíno interesse
                            em favorecer um ecossistema onde as obras podem ser difundidas, reutilizadas e derivadas de
                            maneiras criativas. Quanto mais fácil for reutilizar e derivar obras, mais rica a nossa cultura se
                            torna. <br> <br>
                            Obras Culturais Livres são obras ou expressões que podem ser livremente estudadas,
                            aplicadas, copiadas e/ou modificadas, por qualquer um, para qualquer finalidade!
                            <br><br>
                            E a tecnologia ainda nos possibilitou que uma parte crescente da humanidade possa acessar,
                            criar, modificar, publicar e distribuir vários tipos de obras - obras de arte, materiais científicos
                            e educacionais, software, artigos - resumindo: qualquer coisa que possa ser representada
                            digitalmente. Muitas comunidades têm se formado para exercer estas novas possibilidades e
                            criar uma riqueza de obras reutilizáveis coletivamente.
                            <br><br>
                            Dentre os projetos de Cultura Livre realizamos: Iniciativas de acesso a patrimônio cultural;
                            Projetos de Educação aberta; Abertura de acervos de galerias; e muitos outros.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  </div>
</template>

<script>
  export default {
    layout: 'app',

    head() {
      return {
        titleTemplate: 'Piazentin Advogados',
        meta: [
          { charset: 'utf-8' },
          { name: 'viewport', content: 'width=device-width, initial-scale=1' },

          // hid is used as unique identifier. Do not use `vmid` for it as it will not work
          { hid: 'description', name: 'description', content: '' },
        ],
        script: [{ src: 'https://identity.netlify.com/v1/netlify-identity-widget.js' }],
      };
    },

    data() {
      return {
        lmS: null
      }
    },

    mounted() {
        this.lmS = new this.locomotiveScroll({
        el: document.querySelector("#loco-scroll"),
          smooth: true
      });

      this.lmS.on('scroll', function(obj){
          let scroll = obj["scroll"]["y"]
          let h = window.innerHeight
          let w = window.innerWidth
          var scrollPercent = (scroll / 100)
          
          document.getElementById("bullet").style.top = scrollPercent+"px"
      });

      this.startAnimations();
    },

    beforeDestroy() {
      console.log("destroy lms")
      this.lmS.destroy();
    },

    methods: {
      startAnimations: function(){
        document.getElementById("bullet").style.top = 0+"px"
      }
    }
    
  }
</script>