<template>
  <div>
    <section data-scroll-section class="container section-bottom" id="container">
        <div class="row loco-section" id="row" data-scroll data-scroll-class="loco-show">
            <div class="col-12-sm col-2-md col-start-1-sm col-start-1-md fixed-nav">
                <div class="item-top" data-scroll data-scroll-sticky data-scroll-target="#row">
                    <ul id="fixnav">
                        <li>
                            <a id="fixnav-audiovisual" href="#audiovisual" data-scroll-to>Audiovisual</a>
                        </li>
                        <li>
                            <a id="fixnav-artte-e-design" href="#arte-e-design" data-scroll-to>Arte e Design</a>
                        </li>
                        <li>
                            <a id="fixnav-artes-interpretativas" href="#artes-interpretativas" data-scroll-to>Artes Interpretativas</a>
                        </li>
                        <li>
                            <a id="fixnav-artes-visuais" href="#artes-visuais" data-scroll-to>Artes visuais e Fotografia</a>
                        </li>
                        <li>
                            <a id="fixnav-eventos-e-showbusiness" href="#eventos-e-showbusiness" data-scroll-to>Eventos e Showbusiness</a>
                        </li>
                        <li>
                            <a id="fixnav-literatura" href="#literatura" data-scroll-to>Literatura</a>
                        </li>
                        <li>
                            <a id="fixnav-moda" href="#moda" data-scroll-to>Moda</a>
                        </li>
                        <li>
                            <a id="fixnav-direito-digital" href="#direito-digital" data-scroll-to>Midias Digitais</a>
                        </li>
                        <li>
                            <a id="fixnav-direito-publico" href="#direito-publico" data-scroll-to>Música</a>
                        </li>
                        <li>
                            <a id="fixnav-publicidade-e-propaganda" href="#publicidade-e-propaganda" data-scroll-to>Publicidade e Marketing</a>
                        </li>
                        <li>
                            <a id="fixnav-patrimonio-cultural" href="#patrimonio-cultural" data-scroll-to>Patrimônio Cultural</a>
                        </li>
                        <li>
                            <a id="fixnav-tecnologia-startups" href="#tecnologia-startups" data-scroll-to>tecnologia e Startups</a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="col-10-sm col-9-md col-start-2-sm col-start-4-md">
                <div id="audiovisual" data-scroll data-scroll-class="loco-show" data-scroll-call="audiovisual" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Audiovisual</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Consultoria Jurídica de toda a cadeia de direitos do filme. Planejamento
                      Estratégico para utilização de incentivos fiscais, editais e Fundos Setoriais. Licenciamento e
                      cessão de direitos de autor e conexos, além de obras de todo gênero. Classificação Indicativa,
                      Autorização de Direito de Imagem. Contratos de coprodução, patrocinadores e investidores.</p>
                        </div>
                    </div>
                </div>

                <div id="arte-e-design" data-scroll data-scroll-class="loco-show" data-scroll-call="arte-e-design" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Arte e<br>Design</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Proteção de projetos gráficos; rótulos; embalagens; produtos e objetos.</p>
                        </div>
                    </div>
                </div>

                <div id="artes-interpretativas" data-scroll data-scroll-class="loco-show" data-scroll-call="artes-interpretativas" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Artes Interpretativas</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Proteção autoral sobre as atividades de dança, teatro, música ao vivo, ópera, balé.</p>
                        </div>
                    </div>
                </div>

                <div id="artes-visuais" data-scroll data-scroll-class="loco-show" data-scroll-call="artes-visuais" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Artes Visuais e Fotografia</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Contratos de Obras sobre encomenda; Assessoria Jurídica para galerias e
                      Instituições Culturais; Due diligence antitruste em operações, Formalização contratual para
                      exposições; Contrato de empréstimos de obras. 
                      Violações de direito autoral; Contratos de direito de Imagem; Contratos de serviços; Cessão de imagens.</p>
                        </div>
                    </div>
                </div>

                <div id="eventos-e-showbusiness" data-scroll data-scroll-class="loco-show" data-scroll-call="eventos-e-showbusiness" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Eventos e Showbusiness</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Auxilio no planejamento estratégico do evento; Determinação de riscos
                            a serem neutralizados; Prevenção jurídica de eventos, autorizações e 
                            alvarás; Contratos com empresas terceirizadas; Contratos e visto temporário 
                            para artistas e técnicos.</p>
                        </div>
                    </div>
                </div>

                <div id="literatura" data-scroll data-scroll-class="loco-show" data-scroll-call="literatura" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Literatura</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Contratos de edição; Licenciamentos; Contratos de tradução; Obras Coletivas; Contratos de edição digital.</p>
                        </div>
                    </div>
                </div>

                <div id="moda" data-scroll data-scroll-class="loco-show" data-scroll-call="moda" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Moda</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Assessoria em todas as questões que envolvem violações à propriedade intelectual, 
                                tais como: contrafação, falsificação, cópia não autorizada e uso indevido de marca; 
                                Assessoria em conflitos entre marcas e estilistas; Elaboração e gerenciamento de contratos 
                                de franquia, licenciamento de uso de marca, concessão mercantil, representação comercial; 
                                Contratos entre estilistas, modelos, influenciadores digitais, blogueiros, youtubers.
</p>
                        </div>
                    </div>
                </div>

                <div id="midias-digitais" data-scroll data-scroll-class="loco-show" data-scroll-call="midias-digitais" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Midias <br>Digitais</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Cessão e licenciamento de conteúdos digitais; Publicação online, blogs, E-books e revistas 
                                digitais; Elaboração de Termos e Condições de sites e aplicativos; Elaboração de política de 
                                privacidade.</p>
                        </div>
                    </div>
                </div>

                <div id="musica" data-scroll data-scroll-class="loco-show" data-scroll-call="musica" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Música</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Contratos de Interpretação e gravação; Produção e distribuição de fonogramas 
                                em todas as mídias; Edição de obras musicais; Representação de artistas e 
                                grupos musicais; Negociação com titulares de direitos autorais e associações de 
                                gestão coletiva.
</p>
                        </div>
                    </div>
                </div>

                <div id="publicidade-e-propaganda" data-scroll data-scroll-class="loco-show" data-scroll-call="publicidade-e-propaganda" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Publiciade e Marketing</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Representamos agências de criação, empresas de mídia, profissionais de 
                                marketing, revistas, blogueiros. Oferecemos consultoria jurídica em projetos
                                 e ações publicitárias; Clearance de campanhas publicitárias e de marketing; 
                                 Defesa em processos perante o Conar; Contratos de publicação, licenciamento 
                                 e patrocínio; Elaboração e revisão de contratos de emprego, freelance e de serviços.
</p>
                        </div>
                    </div>
                </div>

                <div id="patrimonio-cultural" data-scroll data-scroll-class="loco-show" data-scroll-call="patrimonio-cultural" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Patrimônio Cultural</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Auxilio em questões de patrimônio material e imaterial, procedimentos de tombamento,
                                 consultoria em ações de defesa do patrimônio cultural.
</p>
                        </div>
                    </div>
                </div>

                <div id="tecnologia-startups" data-scroll data-scroll-class="loco-show" data-scroll-call="tecnologia-startups" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Tecnologia e<br> Startups</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p>Estruturação de negócios e projetos para empresas e instituições de internet, 
                                tecnologia e startups desde a estruturação societária até ações em propriedade intelectual.
</p>
                        </div>
                    </div>
                </div>

                <div id="cultura-livre" data-scroll data-scroll-class="loco-show" data-scroll-call="cultura-livre" data-scroll-offset="500">
                    <div class="row item-top">
                        <div class="col-12-sm col-3-md">
                            <p class="text-xl1 text-upper">Cultura<br>Livre</p>
                        </div>
                        <div class="col-12-sm col-9-md col-start-1-sm col-start-4-md">
                            <p></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  </div>
</template>

<script>
  export default {
    layout: 'app',

    head() {
      return {
        titleTemplate: 'Piazentin Advogados',
        meta: [
          { charset: 'utf-8' },
          { name: 'viewport', content: 'width=device-width, initial-scale=1' },

          // hid is used as unique identifier. Do not use `vmid` for it as it will not work
          { hid: 'description', name: 'description', content: '' },
        ],
        script: [{ src: 'https://identity.netlify.com/v1/netlify-identity-widget.js' }],
      };
    },

    data() {
      return {
        lmS: null
      }
    },

    mounted() {
        this.lmS = new this.locomotiveScroll({
            el: document.querySelector("#loco-scroll"),
            smooth: true
        });

        this.lmS.on('scroll', function(obj){
            let scroll = obj["scroll"]["y"]
            let h = window.innerHeight
            let w = window.innerWidth
            var scrollPercent = (scroll / 18)
            
            document.getElementById("bullet").style.top = scrollPercent+"px"
        });

        this.startAnimations();
    },

    beforeDestroy() {
      console.log("destroy lms")
      this.lmS.destroy();
    },

    methods: {
      startAnimations: function(){
        document.getElementById("bullet").style.top = 0+"px"
      }
    }
    
  }
</script>