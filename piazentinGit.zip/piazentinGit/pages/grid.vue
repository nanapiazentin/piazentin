<template>
  <div class="row">
      <div class="col col-6"></div>
  </div>
</template>

<script>
  export default {
  }
</script>