<template>
  <div>

    <section data-scroll-section class="section-page me">
      <div class="container">
            <div class="row loco-section" data-scroll data-scroll-class="loco-show" data-scroll-offset="80">
                <div class="col-12-sm col-7-sm col-start-2-md">
                    <h1 class="title-xxl">POLÍTICA DE<br> PRIVACIDADE</h1>
                </div>
            </div>
            <div class="section-small">
                <div class="row section-list-small">
                    <div class="col-10-sm col-8-md col-start-2-sm col-start-3-md loco-section" data-scroll data-scroll-class="loco-show">
                        <p>
<span class="content-title">1. Introdução</span>
Bem-vindo ao site Piazentin Advogados <br>
Nossa Política de Privacidade rege sua visita a www.nanasharapiazentin.com e explica como coletamos, salvaguardamos e divulgamos informações resultantes do uso de nosso Serviço.
Temos uma preocupação com a proteção dos dados pessoais de todos aqueles que acessam os conteúdos de nossas publicações ou que contratam nossos serviços. E é pensando nisso que submetemos os tratamentos de dados aos parâmetros estabelecidos em nossa Política de Privacidade.
O propósito dessa Política de Privacidade é dar transparência às operações de tratamento de dados que são realizadas por nós, tornando público o nosso compromisso com a proteção da privacidade e da intimidade dos usuários.
Baseamo-nos especialmente nas disposições e princípios do Marco Civil da Internet (Lei N° 12.965/14) e Lei Geral de Proteção de Dados Pessoais (Lei nº 13.709/2018)

<span class="content-title">2. Definições</span>

Para uma completa compreensão da nossa política de privacidade esclarecemos alguns termos técnicos e/ou definidos em lei:
<br><strong>DADOS PESSOAIS:</strong> informação relacionada a pessoa natural identificada ou identificável; 
<br><strong>DADO PESSOAL SENSÍVEL:</strong> dado pessoal sobre origem racial ou étnica, convicção religiosa, opinião política, filiação a sindicato ou a organização de caráter religioso, filosófico ou político, dado referente à saúde ou à vida sexual, dado genético ou biométrico, quando vinculado a uma pessoa natural;
<br><strong>BANCO DE DADOS:</strong> conjunto estruturado de dados pessoais, estabelecido em um ou em vários locais, em suporte eletrônico ou físico;
<br><strong>TITULAR:</strong> pessoa natural a quem se referem os dados pessoais que são objeto de tratamento;
<br><strong>DADOS DE UTILIZAÇÃO</strong> são dados coletados automaticamente, gerados pelo uso do Serviço ou da própria infraestrutura do Serviço (por exemplo, a duração de uma visita à página).
<br><strong>COOKIES</strong> são pequenos arquivos armazenados no seu dispositivo (computador ou dispositivo móvel), que armazenam, por determinado período de tempo, as informações sobre a navegação do usuário na internet.
<br><strong>CONTROLADOR DE DADOS</strong>, uma pessoa natural ou jurídica, a quem compete as decisões referentes ao tratamento de dados pessoais. Para os fins desta Política de Privacidade, somos um Controlador de Dados de seus dados.
<br><strong>USUÁRIO</strong> é o indivíduo que utiliza nosso serviço. O usuário corresponde ao titular dos dados, que é o titular dos dados pessoais.
 
<span class="content-title">3. Coleta e uso de informações</span>
 
Sempre que necessário para o melhor desempenho de nossos serviços, podemos realizar atividades de tratamento de dados pessoais, sendo que alguns desses tratamentos poderão ocorrer mediante o consentimento do titular enquanto outros, nas hipóteses em que houver permissão legal, ocorrerão independentemente do consentimento. 

<span class="content-title">4. Tipos de dados coletados</span>
 
<strong>Dados pessoais</strong> <br>

Ao usar nosso Serviço, podemos solicitar que você nos forneça certas informações de identificação pessoal que podem ser usadas para entrar em contato ou identificá-lo 
("Dados Pessoais"). Informações de identificação pessoal podem incluir, mas não estão limitadas a:
 
a) Endereço de email
b) Nome e sobrenome
(c) Cookies e dados de uso <br><br>
 
<strong>Dados de uso</strong> <br>

Também podemos coletar informações que seu navegador envia sempre que você visita nosso Serviço ou quando acessa o Serviço por ou através de um dispositivo móvel ("Dados de Uso").
 <br>
Estes Dados de Uso podem incluir informações como o endereço de Protocolo da Internet do seu computador (por exemplo, endereço IP), tipo de navegador, versão do navegador, as páginas do nosso Serviço que você visita, a hora e a data da sua visita, o tempo gasto nessas páginas, exclusivo identificadores de dispositivo e outros dados de diagnóstico.
<br>
Quando você acessa com um dispositivo móvel, esses dados de uso podem incluir informações como o tipo de dispositivo móvel que você usa, o ID exclusivo do seu dispositivo móvel, o endereço IP do seu dispositivo móvel, o seu sistema operacional móvel, o tipo de navegador da Internet móvel você usa identificadores de dispositivo exclusivos e outros dados de diagnóstico.
<br><br>
<strong>Rastreando dados de cookies</strong><br>

Utilizamos cookies e tecnologias de rastreamento semelhantes para rastrear a atividade em nosso Serviço e mantemos certas informações.
<br>
Cookies são arquivos com uma pequena quantidade de dados que podem incluir um identificador exclusivo anônimo. Os cookies são enviados para o seu navegador a partir de um site e armazenados no seu dispositivo. Outras tecnologias de rastreamento também são usadas, como beacons, tags e scripts para coletar e rastrear informações e melhorar e analisar nosso serviço.
<br>
Você pode instruir seu navegador a recusar todos os cookies ou a indicar quando um cookie está sendo enviado. 
<br><br>
<strong>Exemplos de cookies que usamos:</strong> <br>
Cookies essenciais - Alguns cookies são essenciais para acessar a áreas específicas do nosso site. Permitem a navegação no site e a utilização das suas aplicações, tal como acessar áreas seguras do site através de login. Sem estes cookies, os serviços que o exijam não podem ser prestados.
<br>
Cookies analíticos - Utilizamos estes cookies para analisar a forma como os usuários usam o site e monitorar a performance deste. Isto permite-nos fornecer uma experiência de alta qualidade ao personalizar a nossa oferta e rapidamente identificar e corrigir quaisquer problemas que surjam. Por exemplo, usamos cookies de desempenho para saber quais as páginas mais populares, qual o método de ligação entre páginas que é mais eficaz, ou para determinar a razão de algumas páginas estarem a receber mensagens de erro. Baseado na utilização do site, podemos também utilizar estes cookies para destacar artigos ou serviços do site que pensamos ser do interesse dos usuários. Estes cookies são utilizados apenas para efeitos de criação e análise estatística, sem nunca recolher informação de carácter pessoal.
<br>
(a) Cookies de sessão: usamos cookies de sessão para operar nosso serviço.
<br>
(b) Cookies de preferência: usamos cookies de preferência para lembrar suas preferências e várias configurações.
<br>
(c) Cookies de segurança: Utilizamos cookies de segurança para fins de segurança.
<br>
(d) Cookies de publicidade: os cookies de publicidade são usados para atendê-lo com anúncios que podem ser relevantes para você e seus interesses.

<span class="content-title">5. Uso de dados</span>
 
Utilizamos os dados coletados para diversos fins: <br>

(a) para notificá-lo sobre alterações em nosso Serviço;
<br> 
(b) permitir que você participe de recursos interativos do nosso Serviço quando você optar por fazê-lo;
<br>
(c) reunir análises ou informações para que possamos melhorar nosso serviço;
<br>
(d) monitorar o uso do nosso serviço;
<br>
(e)	detectar, prevenir e resolver problemas técnicos
<br>
(f)	Também coletamos informações de cunho pessoal através do preenchimento dos formulários para envio de newsletters e informativos, ou quando é realizado download de algum material gratuito.
<br>
(g)	para qualquer outra finalidade somente  com o seu consentimento.

<span class="content-title">6. Retenção de dados</span>
 
Reteremos seus Dados Pessoais apenas pelo tempo necessário para os fins estabelecidos nesta Política de Privacidade. Também reteremos os Dados de Uso para fins de análise interna. Os dados de uso geralmente são retidos por um período mais curto, exceto quando esses dados são usados para fortalecer a segurança ou melhorar a funcionalidade de nosso Serviço, ou somos legalmente obrigados a reter esses dados por períodos mais longos.
 
<span class="content-title">7. Compartilhamento de Dados</span>
 
O armazenamento de dados pessoais dos usuários de seus serviços, os quais estão localizados em território brasileiro e submetidos às regras previstas nas Leis brasileiras.
<br>
Informaremos aos titulares dos dados toda vez que realizarmos o compartilhamento de dados com terceiros, salvo se decisão judicial ou de autoridade administrativa competente determinar o contrário. 

<span class="content-title">8. Segurança de Dados</span>
 
A segurança dos seus dados é importante para nós, mas lembre-se de que nenhum método de transmissão pela Internet ou método de armazenamento eletrônico é 100% seguro. Embora nos esforcemos para usar meios comercialmente aceitáveis para proteger seus Dados Pessoais, não podemos garantir sua segurança absoluta.
<br>
Entretanto, na eventualidade de ocorrer algum incidente de segurança envolvendo os dados pessoais de seus usuários, que acarrete risco ou dano relevante, nos comprometemos a comunicá-los sobre o ocorrido, sendo certo igualmente que comunicará sua ocorrência às autoridades competentes.
<br>
Se você deseja ser informado sobre os dados pessoais que possuímos sobre você e se deseja que sejam removidos de nossos sistemas, envie um email para contato@nanasharapiazentin.com.

<span class="content-title">9. Google Analytics</span>
 
Podemos usar provedores de serviços de terceiros para monitorar e analisar o uso de nosso serviço. O Google Analytics é um serviço de análise da web oferecido pelo Google que rastreia e relata o tráfego do site. O Google usa os dados coletados para rastrear e monitorar o uso de nosso Serviço. Esses dados são compartilhados com outros serviços do Google. O Google pode usar os dados coletados para contextualizar e personalizar os anúncios de sua própria rede de publicidade.
<br>
Para mais informações sobre as práticas de privacidade do Google, visite a página de Termos de Privacidade do Google: https://policies.google.com/privacy?hl=pt-BR
<br>
Também recomendamos que você reveja a política do Google para proteger seus dados: https://support.google.com/analytics/answer/6004245.

<span class="content-title">10. Links para outros sites</span>
 
Nosso site pode conter links para outros sites que não são operados por nós. Se você clicar em um link de terceiros, será direcionado para o site desse terceiro. Aconselhamos que reveja a Política de Privacidade de todos os sites que visitar.
<br>
Não temos controle e não assumimos nenhuma responsabilidade pelo conteúdo, políticas ou práticas de privacidade de sites ou serviços de terceiros.

<span class="content-title">11. O tratamento de dados sensíveis</span>

Como regra, não realizamos o tratamento de dados pessoais sensíveis dosusuários.
<br>
Na eventualidade de haver necessidade de tratamento desse tipo específico de dado, será prestada ao usuário a devida informação quanto a isso.
15. Tratamento de dados de nossos colaboradores
<br>
O escritório realiza o tratamento de dados pessoais de seus colaboradores e daqueles que se candidatam a vagas profissionais e de estágio que disponibiliza. O mesmo poderá ocorrer com prestadores de serviços contratados ainda que eventuais.
<br>
Os tratamentos de dados pessoais nesses casos destinam-se a finalidades específicas e são realizados de acordo com regras próprias, não submetidos a essa Política de Privacidade.

<span class="content-title">12. Alterações nesta política de privacidade</span>
 
Podemos atualizar nossa Política de Privacidade periodicamente. Notificaremos você sobre quaisquer alterações, publicando a nova Política de Privacidade nesta página.
<br>
Informaremos você por e-mail e / ou um aviso em destaque em nosso Serviço, antes que a alteração entre em vigor e atualize a "data efetiva" na parte superior desta Política de Privacidade.
<br>
É aconselhável que você revise esta Política de Privacidade periodicamente para quaisquer alterações. As alterações a esta Política de Privacidade são efetivas quando publicadas nesta página.


<span class="content-title">13) Seus direitos e deveres</span>

Ressalvada a proteção de segredos comerciais, somos comprometidos com a transparência, assegurada aos usuários de seus serviços informações a respeito dos tratamentos de dados que realizamos, facultando-lhes a correção e a atualização dos dados pessoais que estejam incorretos, inexatos ou desatualizados.
<br>
Também asseguramos, além de todos os demais direitos previstos em Lei, a anonimização, o bloqueio ou a eliminação de dados pessoais que se revelem desnecessários.
<br>
O usuário deverá igualmente agir de maneira colaborativa e transparente, comprometendo-se a fornecer, sempre que solicitado, informações exatas e corretas, assumindo a obrigação de manter todos os seus dados atualizados.
<br>
Seus direitos poderão exercidos por meio do email contato@nanasharapiazentin.com

<span class="content-title">14. Contate-nos</span>

Se você tiver alguma dúvida sobre esta Política de Privacidade, entre em contato conosco por e-mail: contato@nanasharapiazentin.com.



                        </p>
                    </div>
                </div>
            </div>
      </div>
    </section>

  </div>
</template>

<script>
  export default {
    layout: 'app',

    head() {
      return {
        titleTemplate: 'Piazentin Advogados',
        meta: [
          { charset: 'utf-8' },
          { name: 'viewport', content: 'width=device-width, initial-scale=1' },

          // hid is used as unique identifier. Do not use `vmid` for it as it will not work
          { hid: 'description', name: 'description', content: '' },
        ],
        script: [{ src: 'https://identity.netlify.com/v1/netlify-identity-widget.js' }],
      };
    },

    data() {
      return {
        lmS: null
      }
    },

    mounted() {
      this.lmS = new this.locomotiveScroll({
          el: document.querySelector("#loco-scroll"),
          smooth: true
      });

      this.lmS.on('scroll', function(obj){
          let scroll = obj["scroll"]["y"]
          let h = window.innerHeight
          let w = window.innerWidth
          var scrollPercent = (scroll / 92)
          
          document.getElementById("bullet").style.top = scrollPercent+"px"
      });

      this.startAnimations();
    },

    beforeDestroy() {
      console.log("destroy lms")
      this.lmS.destroy();
    },

    methods: {
      startAnimations: function(){
        document.getElementById("bullet").style.top = 0+"px"
      }
    }
    
  }
</script>