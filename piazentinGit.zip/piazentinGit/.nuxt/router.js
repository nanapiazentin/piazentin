import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _3ab4e56a = () => interopDefault(import('../pages/advogada.vue' /* webpackChunkName: "pages/advogada" */))
const _fff1bafa = () => interopDefault(import('../pages/contato.vue' /* webpackChunkName: "pages/contato" */))
const _45f610e4 = () => interopDefault(import('../pages/conteudo.vue' /* webpackChunkName: "pages/conteudo" */))
const _567dd988 = () => interopDefault(import('../pages/escritorio.vue' /* webpackChunkName: "pages/escritorio" */))
const _f391c886 = () => interopDefault(import('../pages/grid.vue' /* webpackChunkName: "pages/grid" */))
const _1ab5fd39 = () => interopDefault(import('../pages/manifesto.vue' /* webpackChunkName: "pages/manifesto" */))
const _6aa3e30f = () => interopDefault(import('../pages/privacidade.vue' /* webpackChunkName: "pages/privacidade" */))
const _37bb78ea = () => interopDefault(import('../pages/servicos.vue' /* webpackChunkName: "pages/servicos" */))
const _1f92390c = () => interopDefault(import('../pages/setores.vue' /* webpackChunkName: "pages/setores" */))
const _c8fef184 = () => interopDefault(import('../pages/site.vue' /* webpackChunkName: "pages/site" */))
const _586409fa = () => interopDefault(import('../pages/trabalhe-conosco.vue' /* webpackChunkName: "pages/trabalhe-conosco" */))
const _724f652a = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/advogada",
    component: _3ab4e56a,
    name: "advogada"
  }, {
    path: "/contato",
    component: _fff1bafa,
    name: "contato"
  }, {
    path: "/conteudo",
    component: _45f610e4,
    name: "conteudo"
  }, {
    path: "/escritorio",
    component: _567dd988,
    name: "escritorio"
  }, {
    path: "/grid",
    component: _f391c886,
    name: "grid"
  }, {
    path: "/manifesto",
    component: _1ab5fd39,
    name: "manifesto"
  }, {
    path: "/privacidade",
    component: _6aa3e30f,
    name: "privacidade"
  }, {
    path: "/servicos",
    component: _37bb78ea,
    name: "servicos"
  }, {
    path: "/setores",
    component: _1f92390c,
    name: "setores"
  }, {
    path: "/site",
    component: _c8fef184,
    name: "site"
  }, {
    path: "/trabalhe-conosco",
    component: _586409fa,
    name: "trabalhe-conosco"
  }, {
    path: "/",
    component: _724f652a,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
